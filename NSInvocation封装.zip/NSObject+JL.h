//
//  NSObject+JL.h
//  NSInvocation
//
//  Created by 潘九龙 on 15/8/14.
//  Copyright (c) 2015年 潘九龙. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (JL)
+ (id)performSelector:(SEL)aSelector withObject:(NSArray *)objects;
@end
