//
//  NSObject+JL.m
//  NSInvocation
//
//  Created by 潘九龙 on 15/8/14.
//  Copyright (c) 2015年 潘九龙. All rights reserved.
//

#import "NSObject+JL.h"

@implementation NSObject (JL)
+ (id)performSelector:(SEL)aSelector withObject:(NSArray *)objects
{
    // 签名中保存了方法的名称/参数/返回值类型
    // 注意: 签名一般是用来设置参数和获取返回值的, 和方法的调用没有太大的关系
    NSMethodSignature *signature = [[self class] instanceMethodSignatureForSelector:aSelector];
   
    // 0.判断传入的方法是否存在, 如果不存在就进行相应处理
    if (signature == nil) {
        
        //方法不存在就抛出一个异常
        NSString *info = [NSString stringWithFormat:@"%@方法找不到",NSStringFromSelector(aSelector)];
        [NSException raise:@"特定异常" format:info,nil];
    }
    
    // 1.创建一个NSInvocation对象
    // NSInvocation中保存了方法所属的对象/方法名称/参数/返回值
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    invocation.target = self;
    invocation.selector = aSelector;
    
    // 注意: 如果需要通过遍历给invocation设置参数, 那么不能遍历objects数组
    // 因为objects数组的长度是不可控
    // 注意: 通过numberOfArguments方法获取的参数个数, 是包含self和_cmd的
    NSUInteger argsCount = signature.numberOfArguments - 2;
    NSUInteger arrCount = objects.count;
    NSUInteger count = MIN(argsCount, arrCount);
    for (int i = 0; i < count;  i++) {
        id obj = objects[i];
        
        // 判断需要设置的参数是否是NSNull, 如果是就设置为nil
        if ([obj isKindOfClass:[NSURL class]]) {
            obj = nil;
        }
        // 2.调用NSInvocation对象的invoke方法
        [invocation setArgument:&obj atIndex:i + 2];
    }
    [invocation invoke];

    // 3.获取方法的返回值
    id res = nil;
    // 3.1判断当前调用的方法, 是否有返回值
    if (signature.methodReturnLength != 0) {
        [invocation getReturnValue:&res];
    }
    return res;
}

@end
